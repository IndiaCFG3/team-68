from django.contrib import admin
from firstapp.models import Teacher,Student,Principal,Question,Answers

# Register your models here.
admin.site.register(Teacher)
admin.site.register(Student)
admin.site.register(Principal)
admin.site.register(Question)
admin.site.register(Answers)

